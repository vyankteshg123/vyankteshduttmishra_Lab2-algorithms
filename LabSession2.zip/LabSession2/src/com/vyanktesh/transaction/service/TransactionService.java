package com.vyanktesh.transaction.service;

import java.util.Scanner;

public class TransactionService {
	
	public void checkTransaction(int[] arr , int target) {
		
		Scanner sc = new Scanner(System.in);
		
		while(target-- !=0) {
			
			boolean flag = false;
			
			int trgtValue;
			
			
			System.out.println("Enter the value of target " );
			trgtValue = sc.nextInt();
			
			int sum = 0;
			
			for(int i =0; i<arr.length; i++) {
				
				sum += arr[i];
				
				if(sum>=trgtValue) {
					
					System.out.println("Target achieved after " +(i + 1)+ " transactions ");
					System.out.println();
					
					flag = true;
					
					
					break;
				}
			}
			
			if(flag == false) {
				
				System.out.println("Given target is not achieved");
				
			}
		}
		sc.close();
	}


}