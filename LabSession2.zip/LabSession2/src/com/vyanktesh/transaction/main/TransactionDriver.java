package com.vyanktesh.transaction.main;

import java.util.Scanner;

import com.vyanktesh.transaction.service.TransactionService;

public class TransactionDriver {
	
	public static void main(String[] args) {
		
		int[] arr;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the size of transaction array : ");
		int size = sc.nextInt();
		
		System.out.println("Enter the values of array : ");
		
		arr = new int[size];
		
		for(int i=0; i < size; i++) {
			
			arr[i] = sc.nextInt();
		}
		
		
		System.out.println("Enter the total no. of target that need to be achieved ");
		int target = sc.nextInt();
		
		TransactionService ts = new TransactionService();
		ts.checkTransaction(arr , target);
		
		sc.close();
		
	}

}
